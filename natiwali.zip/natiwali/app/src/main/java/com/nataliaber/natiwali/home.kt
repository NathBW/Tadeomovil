package com.nataliaber.natiwali

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class home : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val facultad=findViewById<Button>(R.id.facultadhome)
        facultad.setOnClickListener{
            val facultadlanzar = Intent(this, facultades::class.java)
            startActivity(facultadlanzar)
        }


        val grupis=findViewById<Button>(R.id.gruposhome)
        grupis.setOnClickListener{
            val grupislanzar = Intent(this, grupos::class.java)
            startActivity(grupislanzar)
        }
    }
}