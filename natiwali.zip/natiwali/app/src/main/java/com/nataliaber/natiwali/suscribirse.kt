package com.nataliaber.natiwali
import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.widget.Button
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.google.firebase.firestore.AggregateSource
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldPath
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ServerTimestamp
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Source
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.firestoreSettings
import com.google.firebase.firestore.ktx.toObject



class suscribirse : AppCompatActivity() {


    private lateinit var auth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_suscribirse)
        val sus=findViewById<Button>(R.id.iniciar2)
        sus.setOnClickListener {
             fun createAccount(correo2: String, contraseña2: String) {
                // [START create_user_with_email]
                auth.createUserWithEmailAndPassword(correo2, contraseña2)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "createUserWithEmail:success")
                            val user = auth.currentUser
                            updateUI(user)
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(TAG, "createUserWithEmail:failure", task.exception)
                            Toast.makeText(baseContext, "Authentication failed.",
                                Toast.LENGTH_SHORT).show()
                            updateUI(null)
                        }
                    }
                // [END create_user_with_email]
            }

             fun sendEmailVerification() {
                // [START send_email_verification]
                val user = auth.currentUser!!
                user.sendEmailVerification()
                    .addOnCompleteListener(this) { task ->
                        // Email Verification sent
                    }
                // [END send_email_verification]
            }






             fun setup() {
                // [START get_firestore_instance]
                val db = Firebase.firestore
                // [END get_firestore_instance]

                // [START set_firestore_settings]
                val settings = firestoreSettings {
                    isPersistenceEnabled = true
                }
                db.firestoreSettings = settings
                // [END set_firestore_settings]
            }

             fun setupCacheSize() {
                // [START fs_setup_cache]
                val db = Firebase.firestore
                val settings = firestoreSettings {
                    cacheSizeBytes = FirebaseFirestoreSettings.CACHE_SIZE_UNLIMITED
                }
                db.firestoreSettings = settings
                // [END fs_setup_cache]
            }
             fun addAdaLovelace() {
                // [START add_ada_lovelace]
                // Create a new user with a first and last name
                val user = hashMapOf(
                    "email" to auth,
                    "emailVerafied" to true,
                    "iud" to auth.uid,
                    "admin" to false
                )

                // Add a new document with a generated ID
                val db = Firebase.firestore
                db.collection("users")
                    .add(user)
                    .addOnSuccessListener { documentReference ->
                        Log.d(TAG, "DocumentSnapshot added with ID: ${documentReference.id}")
                    }
                    .addOnFailureListener { e ->
                        Log.w(TAG, "Error adding document", e)
                    }
                // [END add_ada_lovelace]
            }

            val suslanzar = Intent(this, home::class.java)
            startActivity(suslanzar)
        }

        auth = Firebase.auth
    }


    companion object {
        private const val TAG = "EmailPassword"
    }

    private fun updateUI(user: FirebaseUser?) {

    }

    private fun reload() {

    }

}



